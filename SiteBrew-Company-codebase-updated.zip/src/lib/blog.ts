export interface BlogPost {
  slug: string;
  title: string;
  description: string;
  date: string;
  readTime: string;
  category: string;
  author: string;
  authorRole: string;
  content: string;
}

export const posts: BlogPost[] = [
  {
    slug: "local-seo-for-charleston-small-businesses",
    title: "Local SEO for Charleston Small Businesses: A Beginner's Guide",
    description:
      "If your business isn't showing up on Google when locals search for your services, you're losing customers every day. Here's how to fix that.",
    date: "January 15, 2026",
    readTime: "6 min read",
    category: "Local SEO",
    author: "David Bouse",
    authorRole: "Co-Founder · SEO & Growth",
    content: `
## Why Local SEO Matters in Charleston

Charleston is a competitive market. Whether you run a restaurant on King Street, a plumbing company in Mount Pleasant, or a boutique on Isle of Palms — your customers are searching Google before they call anyone.

The good news: most small businesses in the Lowcountry aren't doing local SEO well. That means a little effort goes a long way.

## The Three Pillars of Local SEO

### 1. Google Business Profile

Your Google Business Profile (GBP) is the single most important local SEO asset you have. It controls what people see in Google Maps and the "local pack" — the three businesses that appear at the top of search results.

**What to do:**
- Claim and verify your profile at business.google.com
- Add every detail: hours, phone, website, description, photos
- Choose the right primary category (be specific — "Seafood Restaurant" beats "Restaurant")
- Respond to every review, good or bad
- Post updates at least twice a month

### 2. On-Page SEO

Your website needs to tell Google exactly what you do and where you do it.

**Key elements:**
- Include your city in your page title — e.g. "Plumber in Mount Pleasant, SC | Company Name"
- Write a unique meta description that mentions your location
- Add your full address in the footer
- Create a dedicated "Service Areas" page listing the neighborhoods and towns you serve
- Use location keywords naturally in your copy (don't stuff them)

### 3. Local Citations & Directories

A "citation" is any online mention of your business name, address, and phone number (NAP). Consistency is everything — if your address is slightly different on Yelp vs. Google, it hurts your rankings.

**Priority directories to list on:**
- Google Business Profile
- Yelp
- Facebook Business
- Better Business Bureau
- Angi (for trades)
- TripAdvisor (for restaurants and hospitality)
- Local Charleston directories

## Quick Wins You Can Do This Week

1. **Audit your GBP** — make sure every field is filled in and photos are recent
2. **Check your NAP consistency** — Google your business name and look for discrepancies
3. **Ask for reviews** — send a follow-up text or email to your last 10 happy customers with a direct GBP review link
4. **Add location keywords** to your homepage title and H1

## How Long Does It Take?

Local SEO isn't instant, but it's faster than you'd think for a local market. Most of our Charleston clients start seeing measurable movement in rankings within 45–90 days of making these changes consistently.

The key word is *consistently*. One burst of activity won't sustain you — Google rewards businesses that stay active.

---

Need help getting your Georgia or South Carolina business found on Google? [Get in touch with SiteBrew](#contact) and we'll audit your current setup for free.
    `.trim(),
  },
  {
    slug: "why-your-small-business-website-is-losing-you-customers",
    title: "Why Your Small Business Website Is Losing You Customers",
    description:
      "A slow, outdated, or hard-to-navigate website doesn't just look bad — it's actively costing you leads and sales every single day.",
    date: "February 20, 2026",
    readTime: "5 min read",
    category: "Web Design",
    author: "Carter Wilson",
    authorRole: "Founder · Web Development",
    content: `
## The Hard Truth About Old Websites

Most small business owners built their website years ago, ticked the box, and moved on. But the web doesn't stay still — and a website that was fine in 2019 is actively hurting you in 2025.

Here are the most common ways your website is costing you customers right now.

## 1. It Loads Too Slowly

Google's research shows that **53% of mobile users abandon a site that takes more than 3 seconds to load**. On mobile networks in areas like Folly Beach or Isle of Palms, that number climbs higher.

Speed is also a direct Google ranking factor. A slow site ranks lower, meaning fewer people even find you.

**How to check:** Go to [pagespeed.web.dev](https://pagespeed.web.dev) and run your URL. Anything below 70 on mobile needs work.

**Common culprits:**
- Uncompressed images (the #1 offender for small business sites)
- Cheap shared hosting
- Too many plugins (WordPress sites especially)
- No caching

## 2. It Doesn't Work on Mobile

Over 60% of local searches happen on a smartphone. If your website isn't designed for mobile — with tappable buttons, readable text without zooming, and a layout that actually works on a small screen — you're losing more than half your potential customers.

**What to look for:**
- Text that's too small to read without pinching
- Buttons that are too close together
- Content that runs off the screen
- Pop-ups that block the entire page on mobile

## 3. There's No Clear Call to Action

A visitor lands on your site. Now what? If the answer isn't immediately obvious, they leave.

Every page should have one clear next step: Call now. Book online. Get a quote. Request a consultation.

We see this constantly with local Charleston businesses — beautiful brochure websites with no form, no phone number in the header, and no reason for anyone to take action.

## 4. It's Not on HTTPS

If your website still shows "http://" instead of "https://" — or if visitors see a "Not Secure" warning in their browser — they will leave. It signals an untrustworthy site, it's a Google ranking penalty, and it genuinely puts visitor data at risk.

SSL certificates are free today. There's no excuse for not having one.

## 5. The Content Is Outdated

"© 2018." Team photos of people who no longer work there. Services you stopped offering. COVID hours still listed.

Outdated content destroys trust immediately. Visitors assume the business is out of touch — or worse, closed.

## What a Good Small Business Website Does

A high-performing local business website:
- Loads in under 2 seconds on mobile
- Has a phone number and CTA visible without scrolling
- Clearly explains what you do and where you serve
- Is optimised for local search terms
- Looks professional on every screen size
- Has current, accurate content

---

If your website has any of the issues above, the good news is they're all fixable. [Reach out to SiteBrew](/contact) and we'll tell you exactly what's holding your Georgia or South Carolina business back.
    `.trim(),
  },
  {
    slug: "how-to-get-more-google-reviews-for-your-charleston-business",
    title: "How to Get More Google Reviews for Your Charleston Business",
    description:
      "Google reviews are one of the most powerful local SEO signals — and one of the easiest to improve. Here's a simple system that actually works.",
    date: "March 10, 2026",
    readTime: "4 min read",
    category: "Local SEO",
    author: "David Bouse",
    authorRole: "Co-Founder · SEO & Growth",
    content: `
## Reviews Are Local SEO Gold

In Charleston's competitive local market, Google reviews do two things simultaneously: they convince potential customers to choose you, and they tell Google you're a legitimate, active, trusted business worth ranking highly.

A business with 80 reviews and a 4.7 rating will almost always outrank a competitor with 10 reviews and a 4.9 rating — volume matters as much as score.

## The Simplest Review System That Works

Most businesses don't get reviews because they don't ask. And most businesses that do ask, ask awkwardly — "Hey, if you get a chance, maybe leave us a review sometime?"

Here's a system that consistently generates reviews:

### Step 1: Create Your Direct Review Link

Go to your Google Business Profile dashboard and find your "Share review form" link. This takes customers directly to the review box — no hunting through Google Maps required.

Shorten it with bit.ly or branded link so it's easy to share.

### Step 2: Ask at the Right Moment

Timing is everything. The best moment to ask is immediately after a positive experience — while the feeling is fresh.

**For service businesses (plumbers, contractors, cleaners):**
Send a follow-up text 2–3 hours after job completion:
*"Hi [Name], glad we could help today! If you have 60 seconds, a Google review really helps our small business: [link]. Thank you!"*

**For restaurants and retail:**
Train staff to mention it at checkout or on the receipt.

**For professional services:**
Add it to your email signature and follow-up emails.

### Step 3: Make It Dead Simple

Every barrier you remove increases the chance someone follows through. Include the direct link, keep your ask under 2 sentences, and never ask for anything specific — just their honest experience.

### Step 4: Respond to Every Review

Google sees whether you engage with your reviews. Responding to all of them — especially critical ones — signals an active, attentive business.

For positive reviews: Thank them and mention a specific detail.
For negative reviews: Acknowledge, apologise where appropriate, and offer to resolve it offline.

## How Many Do You Need?

For most Charleston local markets, **20–50 reviews** puts you in a strong position. In more competitive categories (restaurants, HVAC, lawyers), you're looking at 75+.

The key is a steady drip — 3–5 new reviews per month is more valuable than a burst of 30 that then stops for a year. Google's algorithm tracks recency.

## Don't Buy Reviews

It's worth saying clearly: purchased reviews violate Google's terms, can get your entire profile suspended, and are easy for Google to detect. It's not worth it.

The system above works. Give it 60 days and you'll be surprised at the difference.

---

Want help setting up your Google Business Profile and local review strategy for your Georgia or South Carolina business? [SiteBrew handles this as part of every website package](/contact) — so you hit the ground running from day one.
    `.trim(),
  },
  {
    slug: "the-real-cost-of-a-bad-website-for-charleston-businesses",
    title: "The Real Cost of a Bad Website for Charleston Businesses",
    description:
      "Most business owners underestimate how much an outdated or underperforming website is actually costing them — in lost leads, lower rankings, and eroded trust.",
    date: "April 10, 2026",
    readTime: "5 min read",
    category: "Web Design",
    author: "Carter Wilson",
    authorRole: "Founder · Web Development",
    content: `
## You're Paying for Your Website Whether It Works or Not

A lot of Charleston business owners think of their website as a sunk cost — they paid for it once, it's live, it's fine. But a website that doesn't perform isn't neutral. It's actively costing you money every single day.

Here's a concrete breakdown of how a bad website drains revenue — and what it takes to turn that around.

## Cost #1: Lost Search Visibility

If your website isn't optimized for local search, you're not showing up when potential customers in Charleston, Mount Pleasant, or Folly Beach search for what you offer. That's not a branding problem — it's a revenue problem.

**The math is simple:**
- 97% of people learn about a local business online before visiting in person (BrightLocal)
- The first three Google results capture over 54% of all clicks
- A business on page 2 of Google might as well not exist for most searchers

A well-built website with proper on-page SEO puts you in front of people who are actively looking to buy. An unoptimized site hides you from them entirely.

## Cost #2: High Bounce Rates = Lost Leads

A bounce is when someone visits your site and leaves without taking any action. High bounce rates mean your site isn't capturing the attention of visitors you've already earned.

**Common reasons visitors bounce immediately:**
- The page loads slowly (over 3 seconds is a dealbreaker on mobile)
- The design looks outdated and untrustworthy
- There's no clear call to action — visitors don't know what to do next
- The site doesn't work properly on their phone

Every bounce is a potential customer who found you and left. If you're spending anything on ads or even just word-of-mouth, a high bounce rate means you're leaking that investment.

## Cost #3: Zero Credibility at First Glance

In Charleston's tight-knit business community, reputation matters. But online, you only have a few seconds to make an impression — and your website is your first handshake.

Studies consistently show that **75% of consumers judge a company's credibility based on its website design**. If your site looks like it was built in 2014, visitors assume your business operates like it's 2014. Outdated design signals:
- Lack of attention to detail
- Possibly out of business
- Not trustworthy with credit card info or personal data

A modern, fast, and professional website communicates the opposite: you're active, legitimate, and worth trusting.

## Cost #4: Missed Mobile Traffic

More than 60% of local searches happen on mobile devices. If your website wasn't built mobile-first — or was built before mobile design was standard — you're delivering a broken experience to the majority of your visitors.

A non-mobile-friendly site means:
- Tiny text that requires zooming
- Buttons too small or too close together to tap
- Forms that are painful to fill out
- Images that break the layout on small screens

Google's algorithm also penalizes non-mobile-friendly websites directly in rankings — so it's both a user experience and an SEO problem simultaneously.

## What a Fixed Website Actually Delivers

Here's what we see when we rebuild a local Charleston business website properly:

- **20–40% reduction in bounce rate** within the first 60 days
- **Increased time on page** as visitors find clear, relevant information
- **More contact form submissions and calls** from qualified local leads
- **Improved Google rankings** for local search terms within 45–90 days

The investment in a properly built website isn't a cost — it's one of the highest-ROI changes a small business can make.

## The Right Question to Ask

Instead of "how much does a website cost?", the better question is: "how much is my current website costing me?"

If you're invisible on Google, losing visitors to a slow load time, or failing to convert the traffic you do get — the answer is probably more than you think.

---

Ready to find out exactly what's holding your site back? [Get a free website audit from SiteBrew](/contact) — no obligation, just a clear picture of where you stand.
    `.trim(),
  },
  {
    slug: "why-georgia-and-south-carolina-small-businesses-need-local-seo-now",
    title: "Why Georgia & South Carolina Small Businesses Need Local SEO Now",
    description:
      "If you run a small business in Georgia or South Carolina and you're not investing in local SEO, you're leaving a significant amount of revenue on the table — here's why that window is closing fast.",
    date: "April 30, 2026",
    readTime: "6 min read",
    category: "Local SEO",
    author: "Carter Wilson",
    authorRole: "Founder · Web Development",
    content: `
## The Southeast Is One of the Fastest-Growing Small Business Markets in the Country

Georgia and South Carolina are booming. Metro Atlanta continues to be one of the top destinations for business relocation and startup activity in the US. Savannah's port expansion is drawing logistics and trade businesses in record numbers. Charleston remains one of the fastest-growing mid-size cities in the country. And cities like Greenville, Columbia, and Augusta are emerging as serious regional hubs.

That growth creates enormous opportunity — but it also means competition is intensifying faster than most small business owners realize. The businesses that invest in their online presence now are the ones that will own local search rankings for years to come. The ones that wait are going to have a much harder climb.

## What "Local SEO" Actually Means for a Georgia or South Carolina Business

Local SEO isn't just about ranking for "[your city] + [your service]" — though that matters enormously. It's the complete system that tells Google you're a legitimate, active, trusted business in a specific geographic area:

**Your Google Business Profile** is the single highest-leverage asset you have. It controls whether you appear in the "local pack" — the map and three business listings that sit above all regular search results. Businesses in the local pack get the majority of local clicks.

**On-page location signals** tell Google's algorithm where you operate and what neighborhoods you serve. Without these, you're invisible to the algorithm even when someone a mile away is searching for exactly what you do.

**Local citations and directory consistency** build your business's authority signal. When your name, address, and phone number are consistent across Google, Yelp, the BBB, and industry-specific directories, Google trusts you more — and ranks you higher.

**Reviews and engagement** are a live ranking signal. A business actively collecting reviews and responding to them climbs rankings faster than a dormant profile with a perfect score from years ago.

## The Georgia Market: What's Unique

Georgia's local search landscape is concentrated but sprawling. Atlanta commands enormous search volume, but the suburban markets — Marietta, Alpharetta, Roswell, Johns Creek — each have distinct local search behaviors. A plumber ranking for "Atlanta plumber" may not capture searches from someone in Alpharetta at all.

Savannah is a different kind of market: a mix of strong tourism traffic and a growing permanent resident base creates a dual-audience SEO challenge that requires intentional targeting.

In mid-size Georgia cities like Augusta, Macon, and Athens, the local competition is often thinner — which means a well-executed SEO strategy can deliver outsized results faster than in larger metros.

## The South Carolina Market: What's Unique

Charleston's competitive density has increased significantly over the last five years. More businesses are investing in their digital presence, which means sitting still is falling behind. The Lowcountry's tourism-driven economy also means seasonal search patterns that smart businesses can get ahead of with the right content and profile activity.

Columbia, as the state capital and home to the University of South Carolina, has a large captive audience of residents and students with high local search activity. Greenville has seen a business explosion tied to its manufacturing and tech growth — and the local SEO competition is still early-stage enough that strong performers can establish durable rankings quickly.

Myrtle Beach and Hilton Head both operate in extremely competitive hospitality markets where reviews and local presence signals are make-or-break.

## The Cost of Waiting

Here's the reality most business owners don't hear until it's too late: local search rankings compound over time. A business that starts building local SEO authority today will be significantly harder to displace in twelve months. A business that waits six months to start is six months behind — and in a growing market, that gap widens faster than expected.

The businesses showing up consistently at the top of local search results in your market right now started working on this 6–18 months ago. The best time to start was then. The second best time is today.

## What a Strong Local SEO Foundation Looks Like

Regardless of your city or industry, a solid local SEO foundation in Georgia or South Carolina requires:

**A fully optimized Google Business Profile** — complete with accurate categories, services, hours, photos updated regularly, and an active review strategy.

**A fast, mobile-first website** — Google ranks mobile performance heavily. If your site loads slowly on a phone, you're penalized before anyone even reads a word.

**Location-specific pages and copy** — if you serve multiple cities or neighborhoods, each deserves its own targeted page. A single homepage cannot rank for every market you want to reach.

**Consistent NAP citations** — your Name, Address, and Phone need to match exactly across every directory and platform where your business is listed.

**A content strategy tied to local intent** — blog posts, service pages, and FAQ content written around the specific questions your local customers are actually searching for.

---

If you run a small business in Georgia or South Carolina and want to understand exactly where your local SEO stands right now, [SiteBrew offers free website and SEO audits](/contact). No pitch — just a clear, honest picture of what's working, what isn't, and what the biggest opportunities are for your specific market.
    `.trim(),
  },
];

export function getPost(slug: string): BlogPost | undefined {
  return posts.find((p) => p.slug === slug);
}
